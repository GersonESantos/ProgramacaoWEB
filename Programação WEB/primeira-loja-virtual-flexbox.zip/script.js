let number = 1;
var x = 2;



var sum = (x,y) => x + y;


console.log(sum(number,x));